This folder should contain the prebuilt k2_viral_20231009 Kraken2 database.
Due to its size (~0.5 GB), please download it from:
https://genome-idx.s3.amazonaws.com/kraken/k2_viral_20231009.tar.gz
Extract here to use in the pipeline.